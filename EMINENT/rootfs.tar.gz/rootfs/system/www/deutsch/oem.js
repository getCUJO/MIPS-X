// JavaScript Document
var _ipcam="Network Camera";
var _options="Netwerk camera-instellingen";
var _ddns_service_list='<option value=0>geen</option><option value=2>DynDns.org(dyndns)</option><option value=3>DynDns.org(statdns)</option><option value=4>DynDns.org(custom)</option><option value=8>3322.org(dyndns)</option><option value=9>3322.org(statdns)</option>';
var _anonymous ='Naam';

